<footer class="container-fluid  position-relative py-6">
    <div class="container">
        <div class="row">
            <div class="footer-widgets widget-count-4 col-12">
                <div id="arkidabout_widget-2" class="widget footer-widget widget_arkidabout_widget">
                    <div class="widget-box">
                        <div class="widget-about">
                            <div class="widget-brand"><img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/general-2/website-logo.png" alt=""></div>
                            <ul id="menu-page-list" class="menu">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#"><i class="fas fa-map-marker-alt"></i>Rohanda Palitpara, Kolkata 700135, West Bengal, INDIA</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#"><i class="fas fa-phone-alt"></i>+91 9147 066 309</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#"><i class="fas fa-envelope"></i>enq.craftobags@gmail.com</a></li>
                            </ul>
                        </div>
                    </div>
                </div><!-- .footer-widget -->
                <div id="nav_menu-1" class="widget footer-widget widget_nav_menu">
                    <div class="widget-box">
                        <div class="widget-title">
                            <h3>By Catergory</h3>
                        </div>
                        <div class="menu-page-list-container">
                            <ul id="menu-page-list" class="menu">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Category 1</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Category 2</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Category 3</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Category 4</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Category 5</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Category 6</a></li>
                            </ul>
                        </div>
                    </div>
                </div><!-- .footer-widget -->
                <div id="dl_company_contact_widget-1" class="widget footer-widget widget_dl_company_contact_widget">
                    <div class="widget-box">
                        <div class="widget-title">
                            <h3>Customer Policy</h3>
                        </div>
                        <div class="menu-page-list-container">
                            <ul id="menu-page-list" class="menu">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 1</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 2</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 3</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 4</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 5</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 6</a></li>
                            </ul>
                        </div>
                    </div>
                </div><!-- .footer-widget -->
                <div id="sc_mailchimp_widget-1" class="widget footer-widget widget_sc_mailchimp_widget">
                    <div class="widget-box">
                        <div class="widget-title">
                            <h3>Usefull Links</h3>
                        </div>
                        <div class="menu-page-list-container">
                            <ul id="menu-page-list" class="menu">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 1</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 2</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 3</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 4</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 5</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><a href="#">Link 6</a></li>
                            </ul>
                        </div>
                    </div>
                </div><!-- .footer-widget -->
                <div id="sc_mailchimp_widget-1" class="widget footer-widget widget_sc_mailchimp_widget">
                    <div class="widget-box">
                        <div class="widget-title">
                            <h3>We Accept</h3>
                        </div>
                        <div class="menu-page-list-container">
                            <ul id="menu-page-list" class="menu">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1266"><img src="images/cards.png" alt="Payment gateways"></li>
                            </ul>
                        </div>
                        <div class="widget-title mt-4">
                            <h3>Follow us</h3>
                        </div>
                        <div class="menu-page-list-container">
                            <ul class="wt-social-icons left">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="footer_bottom p_relative">
    <div class="auto_container">
        <div class="bottom_inner  p_relative">
            <div class="copyright">
                <p>Copyright ©2024 Conference. All Rights Reserved</p>
            </div>
        </div>
    </div>
</div>