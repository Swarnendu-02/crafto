<?php include_once("includes/header.php"); ?>

<div class="container-fluid city-sec p-0 position-relative">
    <div class="city-owl owl-carousel owl-theme col-12">
        <div class="item">
            <a href="#">
                <img src="https://assets.myntassets.com/w_980,c_limit,fl_progressive,dpr_2.0/assets/images/2022/5/31/4031994d-9092-4aa7-aea1-f52f2ae5194f1654006594976-Activewear_DK.jpg">
            </a>
        </div>
        <div class="item">
            <a href="#">
                <img src="https://assets.myntassets.com/w_980,c_limit,fl_progressive,dpr_2.0/assets/images/2022/5/31/4031994d-9092-4aa7-aea1-f52f2ae5194f1654006594976-Activewear_DK.jpg">
            </a>
        </div>
    </div>
</div>
<div class="container-fluid city-sec py-6 position-relative">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="themeHeading">
                    <h3 class="themeTitle"><span>shop by category</span></h3>
                </div>
                <div class="categoryItems w-100">
                    <div class="catSingItems w-100">
                        <div class="catImg w-100">
                            <a href="https://craftoleather.com/product-categories/ladies-bag">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/categories/ladies-bag-1.webp" alt="LADIES BAG" class="w-100" title="LADIES BAG">
                            </a>
                        </div>
                        <div class="catContent">
                            <h4 class="catTitle"><a href="https://craftoleather.com/product-categories/ladies-bag" title="LADIES BAG" tabindex="0">ladies bag</a>
                            </h4>
                        </div>
                    </div>
                    <div class="catSingItems w-100">
                        <div class="catImg w-100">
                            <a href="https://craftoleather.com/product-categories/ladies-bag">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/categories/ladies-bag-1.webp" alt="LADIES BAG" class="w-100" title="LADIES BAG">
                            </a>
                        </div>
                        <div class="catContent">
                            <h4 class="catTitle"><a href="https://craftoleather.com/product-categories/ladies-bag" title="LADIES BAG" tabindex="0">ladies bag</a>
                            </h4>
                        </div>
                    </div>
                    <div class="catSingItems w-100">
                        <div class="catImg w-100">
                            <a href="https://craftoleather.com/product-categories/ladies-bag">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/categories/ladies-bag-1.webp" alt="LADIES BAG" class="w-100" title="LADIES BAG">
                            </a>
                        </div>
                        <div class="catContent">
                            <h4 class="catTitle"><a href="https://craftoleather.com/product-categories/ladies-bag" title="LADIES BAG" tabindex="0">ladies bag</a>
                            </h4>
                        </div>
                    </div>
                    <div class="catSingItems w-100">
                        <div class="catImg w-100">
                            <a href="https://craftoleather.com/product-categories/ladies-bag">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/categories/ladies-bag-1.webp" alt="LADIES BAG" class="w-100" title="LADIES BAG">
                            </a>
                        </div>
                        <div class="catContent">
                            <h4 class="catTitle"><a href="https://craftoleather.com/product-categories/ladies-bag" title="LADIES BAG" tabindex="0">ladies bag</a>
                            </h4>
                        </div>
                    </div>
                    <div class="catSingItems w-100">
                        <div class="catImg w-100">
                            <a href="https://craftoleather.com/product-categories/ladies-bag">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/categories/ladies-bag-1.webp" alt="LADIES BAG" class="w-100" title="LADIES BAG">
                            </a>
                        </div>
                        <div class="catContent">
                            <h4 class="catTitle"><a href="https://craftoleather.com/product-categories/ladies-bag" title="LADIES BAG" tabindex="0">ladies bag</a>
                            </h4>
                        </div>
                    </div>
                    <div class="catSingItems w-100">
                        <div class="catImg w-100">
                            <a href="https://craftoleather.com/product-categories/ladies-bag">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/categories/ladies-bag-1.webp" alt="LADIES BAG" class="w-100" title="LADIES BAG">
                            </a>
                        </div>
                        <div class="catContent">
                            <h4 class="catTitle"><a href="https://craftoleather.com/product-categories/ladies-bag" title="LADIES BAG" tabindex="0">ladies bag</a>
                            </h4>
                        </div>
                    </div>
                    <div class="catSingItems w-100">
                        <div class="catImg w-100">
                            <a href="https://craftoleather.com/product-categories/ladies-bag">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/categories/ladies-bag-1.webp" alt="LADIES BAG" class="w-100" title="LADIES BAG">
                            </a>
                        </div>
                        <div class="catContent">
                            <h4 class="catTitle"><a href="https://craftoleather.com/product-categories/ladies-bag" title="LADIES BAG" tabindex="0">ladies bag</a>
                            </h4>
                        </div>
                    </div>
                    <div class="catSingItems w-100">
                        <div class="catImg w-100">
                            <a href="https://craftoleather.com/product-categories/ladies-bag">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/categories/ladies-bag-1.webp" alt="LADIES BAG" class="w-100" title="LADIES BAG">
                            </a>
                        </div>
                        <div class="catContent">
                            <h4 class="catTitle"><a href="https://craftoleather.com/product-categories/ladies-bag" title="LADIES BAG" tabindex="0">ladies bag</a>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid  about-sec">

    <div class="aboutImgSec"><img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/cms/about-img.jpg" class="img-fluid w-100" title="" alt=""></div>

    <div class="container">
        <div class="row ">
            <div class="col-12  col-md-6 offset-md-6">
                <div class="aboutContenSec">
                    <h4 class="aboutTitle">We only use the highest quality full-grain leather. Fine luxury leather goods from Craftoleather, with more affordable prices by cutting out the middle retailers and selling directly to you, the customer.</h4>
                    <h5 class="aboutSmallTitle">We place an emphasis on simple, timeless designs and finish them off with a few basic touches that draw attention to the leather's natural beauty without taking away from it.</h5>
                    <a href="#" class="ctaBtn">View &amp; Shop</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative">
    <div class="container">
        <div class="row">
            <div class="themeHeading">
                <h3 class="themeTitle"><span>latest products</span></h3>
            </div>
            <div class="prd_i_grd col-12 mt-0">
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative ladibag">
    <div class="container">
        <div class="row">
            <div class="themeHeading">
                <h3 class="themeTitle"><span>ladies bag</span></h3>
            </div>
            <div class="prd_i_grd col-12 mt-0">
            <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative">
    <div class="container">
        <div class="row">
            <div class="themeHeading">
                <h3 class="themeTitle"><span>laptop bag</span></h3>
            </div>
            <div class="prd_i_grd col-12 mt-0">

                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
                <div class="prd_list_box">
                    <a href="#" class="prd_list_box_a">
                        <div class="prd_img position-relative">
                            <img src="images/20c-400x400.jpg" class="w-100 h-100">
                            <i class="fas fa-heart wishlisted"></i>
                            <span class="prd_grd_rate">5 <i class="fas fa-star"></i> | 455</span>
                        </div>
                        <div class="prd_des">
                            <h2>Isla</h2>
                            <h3>Croc Nov Women Grey Tote Bag</h3>

                        </div>
                        <div class="prd_prc">
                            <h4><i class="fas fa-rupee-sign"></i> 100</h4>
                            <h5><i class="fas fa-rupee-sign"></i> 80</h5>
                            <h6>(20% OFF)</h6>
                        </div>
                    </a>
                    <div class="prd_footer">
                        <button><i class="fas fa-shopping-bag"></i>add to cart</button>
                        <button><i class="fas fa-heart"></i>wishlist</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid p-0 position-relative">

    <div class="type_grd">
        <div class="contentThumSec">
            <div class="imgThumb" style="background-image: url(https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/cms/conimg1.jpg);">
                <div class="imgThumbContentSec"><span>We are able to provide our customers with a very valuable lifetime warranty by removing the inherent variability of sewing machines from the equation.</span></div>
            </div>
        </div>
        <div class="contentThumSec">
            <div class="imgThumb" style="background-image: url(https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/cms/conimg1.jpg);">
                <div class="imgThumbContentSec"><span>We are able to provide our customers with a very valuable lifetime warranty by removing the inherent variability of sewing machines from the equation.</span></div>
            </div>
        </div>
        <div class="contentThumSec">
            <div class="imgThumb" style="background-image: url(https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/cms/conimg1.jpg);">
                <div class="imgThumbContentSec"><span>We are able to provide our customers with a very valuable lifetime warranty by removing the inherent variability of sewing machines from the equation.</span></div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative">
    <div class="container">
        <div class="row">
            <div class="themeHeading center-heading col-12">
                <h4 class="themeSmallTitle">ABOUT LEATHER</h4>
                <h3 class="themeTitle"><span>Stablized Leather Product</span></h3>
            </div>
            <div class="col-12 col-md-10 offset-md-1 proFetureSecs">
                <div class="profetItemsInner text-black"><span class="icon"><img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/cms/water-proof-1.webp" class="img-fluid" title="Water Proof" alt=""></span>
                    <h4 class="proTitle fs-16 fs-lg-18 fs-xl-20 themefont2 theme-gray-color mab-10">Water Proof</h4>
                    <p>Yes, it has some water resistance, but too much water will cause the leather to become wet- due to the material's permeable nature</p>
                </div>
                <div class="profetItemsInner text-black"><span class="icon"><img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/cms/water-proof-1.webp" class="img-fluid" title="Water Proof" alt=""></span>
                    <h4 class="proTitle fs-16 fs-lg-18 fs-xl-20 themefont2 theme-gray-color mab-10">Water Proof</h4>
                    <p>Yes, it has some water resistance, but too much water will cause the leather to become wet- due to the material's permeable nature</p>
                </div>
                <div class="profetItemsInner text-black"><span class="icon"><img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/cms/water-proof-1.webp" class="img-fluid" title="Water Proof" alt=""></span>
                    <h4 class="proTitle fs-16 fs-lg-18 fs-xl-20 themefont2 theme-gray-color mab-10">Water Proof</h4>
                    <p>Yes, it has some water resistance, but too much water will cause the leather to become wet- due to the material's permeable nature</p>
                </div>
                <div class="profetItemsInner text-black"><span class="icon"><img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/cms/water-proof-1.webp" class="img-fluid" title="Water Proof" alt=""></span>
                    <h4 class="proTitle fs-16 fs-lg-18 fs-xl-20 themefont2 theme-gray-color mab-10">Water Proof</h4>
                    <p>Yes, it has some water resistance, but too much water will cause the leather to become wet- due to the material's permeable nature</p>
                </div>
                <div class="profetItemsInner text-black"><span class="icon"><img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/cms/water-proof-1.webp" class="img-fluid" title="Water Proof" alt=""></span>
                    <h4 class="proTitle fs-16 fs-lg-18 fs-xl-20 themefont2 theme-gray-color mab-10">Water Proof</h4>
                    <p>Yes, it has some water resistance, but too much water will cause the leather to become wet- due to the material's permeable nature</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid citynews-sec py-6 pt-0 position-relative">
    <div class="container">
        <div class="row">
            <div class="themeHeading center-heading col-12">
                <h4 class="themeSmallTitle">Leather & Style</h4>
                <h3 class="themeTitle"><span>Trending News</span></h3>
            </div>
            <div class="news-owl owl-carousel owl-theme col-12">
                <div class="item">
                    <a href="#">
                        <div class="blogsection">
                            <div class="blogImg">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/blogs/27-800x800.webp" class="img-fluid w-100" title="" alt="Master crafted Marvels: Exploring the World of Designer Leather Backpacks">
                            </div>
                            <div class="blogContent">
                                <span class="blogTags">Ecommerce</span>
                                <h4 class="blogTitle">Master crafted Marvels: Exploring the World of Designer Leather Backpacks</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="item">
                    <a href="#">
                        <div class="blogsection">
                            <div class="blogImg">
                                <img src="https://pub-715557ae6bc24ac8ae7df4a03e2e8ed5.r2.dev/blogs/27-800x800.webp" class="img-fluid w-100" title="" alt="Master crafted Marvels: Exploring the World of Designer Leather Backpacks">
                            </div>
                            <div class="blogContent">
                                <span class="blogTags">Ecommerce</span>
                                <h4 class="blogTitle">Master crafted Marvels: Exploring the World of Designer Leather Backpacks</h4>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 course-wrap">
    <div class="container">
        <div class="row">
            <div class="themeHeading center-heading col-12">
                <h4 class="themeSmallTitle">Testimonials</h4>
                <h3 class="themeTitle"><span>What people say's about us</span></h3>
            </div>
            <div class="col-12">
                <div class="course-owl owl-carousel owl-theme">
                    <div class="item">
                        <div class="inner">
                            <div class="testi-thumb">
                                <img src="https://themes.dynamiclayers.net/arkid/wp-content/uploads/sites/15/2020/04/testi-3.png">
                            </div>
                            <div class="testi-content">
                                <p>"Thanks for the guiding us through the construction process, understanding, and we always ready to accommodate our needs. We love our new space!"</p>
                                <h3>José Carpio <span>Architect</span></h3>
                                <ul class="ratings star-4">
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                </ul>
                            </div>
                            <i class="fa fa-quote-right quote-icon"></i>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6">
    <div class="container">
        <div class="row">
            <div class="themeHeading center-heading col-12">
                <h4 class="themeSmallTitle">Newsletter</h4>
                <h3 class="themeTitle"><span>Join Our Mailing List and Stay Updated</span></h3>
            </div>
            <div class="col-12 col-md-6 offset-md-3">
                <form action="#" class="wt-subscribe-form">
                    <input type="email" name="email" placeholder="Email *" required="">
                    <input type="hidden" name="action" value="mailchimpsubscribe">
                    <button class="submit">Subscribe</button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include_once("includes/footer.php"); ?>
</body>
<script>
    $('.city-owl').owlCarousel({
        loop: true,
        nav: true,
        margin: 0,
        smartSpeed: 1000,
        autoplay: 6000,
        items: 1,
        navText: [
            '<i class="fal fa-long-arrow-left"></i>',
            '<i class="fal fa-long-arrow-right"></i>'
        ],

    });
    $('.news-owl').owlCarousel({
        loop: true,
        nav: true,
        margin: 15,
        dots: false,
        smartSpeed: 1000,
        autoplay: 6000,
        items: 5,
        navText: [
            '<i class="fal fa-long-arrow-left"></i>',
            '<i class="fal fa-long-arrow-right"></i>'
        ],

    });
    $(".course-owl").owlCarousel({
        loop: true,
        margin: 30,
        dots: true,
        nav: true,
        smartSpeed: 1000,
        autoplay: 6000,
        navText: [
            '<i class="fal fa-long-arrow-left"></i>',
            '<i class="fal fa-long-arrow-right"></i>'
        ],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            800: {
                items: 1
            },
            1024: {
                items: 2
            }
        }
    });
</script>

</html>